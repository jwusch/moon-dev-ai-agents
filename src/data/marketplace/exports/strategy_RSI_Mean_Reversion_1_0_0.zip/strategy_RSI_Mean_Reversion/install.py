#!/usr/bin/env python
"""
Installation script for RSI Mean Reversion strategy
"""

import os
import shutil
import sys
from pathlib import Path

def install_strategy():
    # Get Moon Dev project root
    project_root = os.environ.get('MOONDEV_PROJECT_ROOT')
    if not project_root:
        print("Please set MOONDEV_PROJECT_ROOT environment variable")
        return False
    
    # Strategy source file
    strategy_file = Path(__file__).parent / "RSI_Mean_Reversion.py"
    
    # Destination
    dest_dir = Path(project_root) / "src" / "strategies"
    dest_dir.mkdir(parents=True, exist_ok=True)
    
    dest_file = dest_dir / strategy_file.name
    
    # Copy strategy
    shutil.copy2(strategy_file, dest_file)
    print(f"Strategy installed to: {dest_file}")
    
    # Install dependencies
    print("Installing dependencies...")
    os.system("pip install -r requirements.txt")
    
    print("Installation complete!")
    return True

if __name__ == "__main__":
    install_strategy()
