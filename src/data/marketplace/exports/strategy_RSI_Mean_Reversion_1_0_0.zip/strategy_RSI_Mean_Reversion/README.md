# RSI Mean Reversion

## Description
A classic mean reversion strategy using RSI to identify oversold/overbought conditions

## Strategy Information
- **Author**: moon_dev
- **Version**: 1.0.0
- **Created**: 2025-11-30
- **Category**: mean_reversion, technical
- **Risk Level**: low

## Requirements
- **Minimum Capital**: $100.0
- **Supported Timeframes**: 15m, 1H, 4H
- **Supported Instruments**: BTC, ETH, SOL
- **Python Dependencies**: pandas_ta

## Performance Summary
- **Total Return**: 226.26%
- **Sharpe Ratio**: 3.576
- **Win Rate**: 72.0%
- **Max Drawdown**: -11.35%

## Installation

### Automatic Installation
```bash
python install.py
```

### Manual Installation
1. Copy the strategy file to your `src/strategies/` directory
2. Install required dependencies: `pip install -r requirements.txt`
3. Run with your preferred agent or backtesting system

## Usage

### With Moon Dev Trading System
```python
from src.agents.strategy_agent import StrategyAgent

agent = StrategyAgent()
agent.run()
```

### Standalone Backtesting
```python
from backtesting import Backtest
from your_strategy import YourStrategy

bt = Backtest(data, YourStrategy, cash=10000, commission=.002)
stats = bt.run()
print(stats)
```

## Support
- Discord: https://discord.gg/8UPuVZ53bh
- YouTube: Moon Dev Channel

## License
This strategy is provided as-is for educational purposes.
